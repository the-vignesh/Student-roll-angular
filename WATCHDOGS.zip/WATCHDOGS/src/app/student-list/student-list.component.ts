import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'; // ✅ Correct import

@Component({
  selector: 'app-student-list',
  standalone: true,
  imports: [CommonModule, FormsModule], // ✅ Correct placement
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent {
  students: string[] = ['Alice', 'Bob', 'Charlie'];
  newStudent = '';
  searchTerm = '';

  get filteredStudents() {
    return this.students.filter(s =>
      s.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }

  addStudent() {
    const name = this.newStudent.trim();
    if (name && !this.students.includes(name)) {
      this.students.push(name);
      this.newStudent = '';
    }
  }

  removeStudent(name: string) {
    this.students = this.students.filter(s => s !== name);
  }
}
